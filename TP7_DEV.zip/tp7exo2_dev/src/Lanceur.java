public class Lanceur {
    public static void main(String[] args){
        Menu.menu();
    }
}

