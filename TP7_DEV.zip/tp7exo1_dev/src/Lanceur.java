public class Lanceur {
    /*
    * La class Lanceur permet d'executer le main
    * Dans le main, la class GestionnaireDeDessins est appelé afin de faire fonctionner le menu
     */
    public static void main(String[] args){
        GestionnaireDeDessins.selectionDessins();
    }
}
